package com.example.akaash.assignment7_1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class GoogleSearch extends AppCompatActivity {

    private Button btnsearch;
    private EditText txtval;
    String var_info;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_google_search);

        txtval=(EditText)findViewById(R.id.editText);
        btnsearch=(Button)findViewById(R.id.button);

        btnsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                var_info=txtval.getText().toString();

                Uri uri=Uri.parse("http://www.google.com/#q="+var_info);
                Intent intent=new Intent(Intent.ACTION_VIEW,uri);
                startActivity(intent);
            }
        });
    }
}
